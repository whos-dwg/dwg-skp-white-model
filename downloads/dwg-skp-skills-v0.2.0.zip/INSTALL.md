# DWG → SKP paired skills v0.2.0 (Pre-release)

Source and full documentation: https://github.com/whos-dwg/dwg-skp-white-model
License: MIT, Copyright (c) 2026 whos-dwg.

Extract into a dedicated folder and keep the two skills under the same skills/ parent.
This bundle includes the shared Python runtime, Ruby bridge and verified dependency manifests.
It does not include Python, Shapely, AutoCAD, .NET or SketchUp native dependencies.

Use Python 3.11+ with Shapely >=2.0,<3. Install matplotlib >=3.8 only for optional PNG reviews.
The Python interpreter launching the skills must be able to import these dependencies.

## Install

From the extracted bundle root, replace D:/Skills with your actual skills parent directory.
Install the matching core first, then the sync skill. Existing installations are backed up.

```powershell
python tools/install_skill.py --target D:/Skills/dwg-layered-skp --dry-run
python tools/install_skill.py --target D:/Skills/dwg-layered-skp
python tools/install_skill.py --skill dwg-skp-sync --target D:/Skills/dwg-skp-sync --dry-run
python tools/install_skill.py --skill dwg-skp-sync --target D:/Skills/dwg-skp-sync
python D:/Skills/dwg-layered-skp/scripts/dwg_to_skp.py doctor
python D:/Skills/dwg-skp-sync/scripts/dwg_skp_sync.py doctor
```

The sync skill is a thin entry point and requires its exact sibling core release.
Do not modify manifests or mix versions. No live models are saved by these install/doctor commands.
DWG decoding and native SKP build/readback require the environments documented in the source README.
Initial modeling uses dwg-layered-skp; an existing source-bound model uses dwg-skp-sync.
