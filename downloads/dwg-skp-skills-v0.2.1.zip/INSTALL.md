# DWG → SKP paired skills v0.2.1 (Pre-release)

Project: https://github.com/whos-dwg/dwg-skp-white-model
License: MIT. Python 3.11+ and Shapely >=2,<3 are required separately.
AutoCAD, .NET and SketchUp native dependencies are not included.

Extract into a dedicated folder and keep both skills under the same skills/ parent.
From this extracted bundle, install the core before the sync skill:

```powershell
python tools/install_skill.py --target D:/Skills/dwg-layered-skp --dry-run
python tools/install_skill.py --target D:/Skills/dwg-layered-skp
python tools/install_skill.py --skill dwg-skp-sync --target D:/Skills/dwg-skp-sync --dry-run
python tools/install_skill.py --skill dwg-skp-sync --target D:/Skills/dwg-skp-sync
python D:/Skills/dwg-layered-skp/scripts/dwg_to_skp.py doctor
python D:/Skills/dwg-skp-sync/scripts/dwg_skp_sync.py doctor
```

Replace D:/Skills with your skills parent. Existing installations are backed up.
Use both skills from v0.2.1; do not mix manifests or disable integrity checks.
These install/doctor commands do not contact or modify active CAD/SKP models.
